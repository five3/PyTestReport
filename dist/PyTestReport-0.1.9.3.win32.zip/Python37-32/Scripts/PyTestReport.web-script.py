#!C:\Python37-32\python.exe
# EASY-INSTALL-ENTRY-SCRIPT: 'PyTestReport==0.1.9.3','console_scripts','PyTestReport.web'
__requires__ = 'PyTestReport==0.1.9.3'
import re
import sys
from pkg_resources import load_entry_point

if __name__ == '__main__':
    sys.argv[0] = re.sub(r'(-script\.pyw?|\.exe)?$', '', sys.argv[0])
    sys.exit(
        load_entry_point('PyTestReport==0.1.9.3', 'console_scripts', 'PyTestReport.web')()
    )
