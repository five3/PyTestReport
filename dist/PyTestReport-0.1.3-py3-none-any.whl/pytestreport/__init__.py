from .HTMLTestRunner import HTMLTestRunner as TestRunner, main

__all__ = ['TestRunner', 'main', 'shell', 'web']


def shell():
    pass


def web():
    pass
