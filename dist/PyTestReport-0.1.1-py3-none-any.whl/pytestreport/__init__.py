from .HTMLTestRunner import HTMLTestRunner as TestRunner

__all__ = ['TestRunner', 'shell', 'web']


def shell():
    pass


def web():
    pass
